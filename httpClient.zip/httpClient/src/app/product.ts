export class Products {
  pname!: string;
  pdesc!: string;
  pprice!: number;
  id?: string;
}
